#ifndef VIDEO_EFFECTS_SDK_INCLUDE_TSVB_PIPELINE_CONFIGURATION_H
#define VIDEO_EFFECTS_SDK_INCLUDE_TSVB_PIPELINE_CONFIGURATION_H

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, TSVBBackend)
{
	/// CPU-based pipeline.
	TSVBBackendCPU = 1,
	/// GPU-based pipeline. Currently Metal.
	TSVBBackendGPU = 2
} NS_SWIFT_NAME(Backend);

typedef NS_ENUM(NSInteger, TSVBSegmentationPreset)
{
	/// Quality is preferred.
	TSVBSegmentationPresetQuality = 0,
	/// Balanced quality and speed.
	TSVBSegmentationPresetBalanced = 1,
	/// Speed is preferred.
	TSVBSegmentationPresetSpeed = 2,
	/// Speed is prioritized.
	TSVBSegmentationPresetLightning = 3,
} NS_SWIFT_NAME(SegmentationPreset);

NS_SWIFT_NAME(PipelineConfiguration)
@protocol TSVBPipelineConfiguration<NSObject>

/// Determines pipeline that performs image processing.
@property(nonatomic) TSVBBackend backend;

/// Segmentation mode allow to choose combination of quality and speed of segmentation. Balanced mode is enabled by default.
@property(nonatomic) TSVBSegmentationPreset segmentationPreset;

/// Determines Apple Neural Engine acceleration is enabled.
///
/// Has effect on system with `Apple Neural Engine` support. If host system does not support `Neural Engine` then the setting is ignored.
///
/// Supported on Mac with M1 chips and newer. And iPhones of 2018 and newer.
@property(nonatomic) bool segmentationOnNeuralEngineEnabled NS_SWIFT_NAME(isSegmentationOnNeuralEngineEnabled);

@end

#endif
