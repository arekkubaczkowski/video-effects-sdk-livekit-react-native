#ifndef VIDEO_EFFECTS_SDK_INCLUDE_TSVB_GL_DEVICE_CONTEXT_H
#define VIDEO_EFFECTS_SDK_INCLUDE_TSVB_GL_DEVICE_CONTEXT_H

#import <TSVB/TSVBDeviceContext.h>

@protocol TSVBGLDeviceContext<TSVBDeviceContext>

@end

#endif
