#ifndef VIDEO_EFFECTS_SDK_INCLUDE_TSVB_FRAME_FACTORY_H
#define VIDEO_EFFECTS_SDK_INCLUDE_TSVB_FRAME_FACTORY_H

#import <TSVB/TSVBFrame.h>

NS_SWIFT_NAME(FrameFactory)
@protocol TSVBFrameFactory<NSObject>


/// Creates a video frame from raw pixel data, either by wrapping or copying the input buffer.
///
/// - note: When `makeCopy:NO`, the caller must retain ownership of data until the pipeline finishes processing all frames using it.
///
/// - parameter format: Pixel format (must be RGBA or BGRA).
/// - parameter data: Pointer to raw packed pixel data
/// - parameter bytesPerLine:Stride (bytes per row) of the pixel data.
/// - parameter width: The width of the frame in pixels.
/// - parameter height: The height of the frame in pixels.
/// - parameter makeCopy: If true,  creates an internal copy of the data,  otherwise wraps the input pointer directly (faster, but caller MUST keep data valid until processing completes).
- (nullable id<TSVBFrame>) newFrameWithFormat:(TSVBFrameFormat)format
										 data:(nonnull void*)data
								 bytesPerLine:(unsigned int)bytesPerLine
										width:(unsigned int)width
									   height:(unsigned int)height
									makeCopy:(bool)makeCopy NS_SWIFT_NAME(newFrame(format:data:bytesPerLine:width:height:makeCopy:));

/// Loads an image from the file
///
/// - parameter withContentOfFile: Full path to an image file (If you have an URL, you can obtain the path via [URL.path](https://developer.apple.com/documentation/foundation/url/path) or [NSURL.path](https://developer.apple.com/documentation/foundation/nsurl/path) ).
-(nullable id<TSVBFrame>) imageWithContentOfFile:(nullable NSString*)filePath;

/// Loads an image from the encoded image data
///
/// Convenience method to load in-memory image. Helpful for in-memory image assets.
/// - parameter data: Encoded (compressed) image data, example, png buffer or jpeg buffer.
-(nullable id<TSVBFrame>) imageWithData:(nullable NSData*)data;

@end

#endif
