#ifndef VIDEO_EFFECTS_SDK_INCLUDE_TSVB_EAGL_DEVICE_CONTEXT_H
#define VIDEO_EFFECTS_SDK_INCLUDE_TSVB_EAGL_DEVICE_CONTEXT_H

#import <TSVB/TSVBGLDeviceContext.h>

#import <OpenGLES/EAGL.h>

@interface TSVBEAGLDeviceContext : NSObject<TSVBGLDeviceContext>

-(nullable id)initWithEAGL:(nonnull EAGLContext*)context;

+(nullable id)deviceContextWithEAGL:(nullable EAGLContext*)context;

@property(nonatomic, readonly, nonnull)EAGLContext* eaglContext;

@end

#endif
