#ifndef VIDEO_EFFECTS_SDK_INCLUDE_TSVB_AUTHORIZATION_H
#define VIDEO_EFFECTS_SDK_INCLUDE_TSVB_AUTHORIZATION_H

#import <Foundation/Foundation.h>

/// Describes result of authorization process.
typedef NS_ENUM(NSInteger, TSVBAuthStatus)
{
	/// Authrization finished with error, example missing internet connection.
	TSVBAuthStatusError = 0,
	/// Authorization finished sucessfully, the SDK can be used.
	TSVBAuthStatusActive = 1,
	/// Such customer has no license or the license revoked.
	TSVBAuthStatusInactive = 2,
	/// The license is expired. Contact us to update it.
    TSVBAuthStatusExpired = 3
} NS_SWIFT_NAME(AuthStatus);

/// Holds result of authorization.
NS_SWIFT_NAME(AuthResult)
@protocol TSVBAuthResult<NSObject>

/// The status of authorization process.
@property(nonatomic, readonly) TSVBAuthStatus status;

@end

#endif
