#ifndef VIDEO_EFFECTS_SDK_INCLUDE_TSVB_SDK_FACTORY_H
#define VIDEO_EFFECTS_SDK_INCLUDE_TSVB_SDK_FACTORY_H

#import <Foundation/Foundation.h>

#import <TSVB/TSVBAuthorization.h>

@protocol TSVBFrameFactory;
@protocol TSVBGLFrameFactory;
@protocol TSVBPipeline;
@protocol TSVBGLFrameFactory;
@protocol TSVBDeviceContext;
@protocol TSVBGLDeviceContext;

typedef void (^TSVBAuthCompletionHandler) (id<TSVBAuthResult>_Nullable result, NSError*_Nullable error);

/// This is the entry point of the SDK. It is required to create a video pipeline and perform authorization.
NS_SWIFT_NAME(SDKFactory)
@interface TSVBSDKFactory : NSObject

/// Performs authorization of the instance.
///
/// ``TSVBSDKFactory`` can not be used until it's authorized.  
/// Method performs https request to obtain license for customerID.
/// - note: Internet connection is required.
/// > Tip: For swift use async/await syntax. See ``TSVBSDKFactory``.
/// - parameter customerID: Your unique customer id
/// - parameter completionHandler: Callback to be called on completion.
-(void)authWithCustomerID:(nonnull NSString*)customerID completionHandler:(nonnull TSVBAuthCompletionHandler)completionHandler
	NS_SWIFT_NAME(auth(customerID:completionHandler:));

/// Performs authorization of the instance.
///
/// Equivalent to ``TSVBSDKFactory/authWithCustomerID:completionHandler:`` with added support for a custom authentication server URL.
/// - parameter customerID: Your unique customer id
/// - parameter apiUrl: URL of custom server.
/// - parameter completionHandler: Callback to be called on completion.
-(void)authWithCustomerID:(nonnull NSString*)customerID apiUrl:(nullable NSURL*)apiUrl completionHandler:(nonnull TSVBAuthCompletionHandler)completionHandler
	NS_SWIFT_NAME(auth(customerID:apiUrl:completionHandler:));

/// Offline authorization with a secret key.
///
/// Authorizes an instance of ``TSVBSDKFactory`` similar to ``TSVBSDKFactory/authWithCustomerID:completionHandler:``, but performs license verification without web requests.
/// Internet connection is not required.
/// - Parameter key: Unique client's secret key. DO NOT reveal it.
-(nonnull id<TSVBAuthResult>)authWithKey:(nonnull NSString*)key NS_SWIFT_NAME(auth(key:));

- (nullable id<TSVBFrameFactory>) newFrameFactory;

- (nullable id<TSVBGLFrameFactory>) newGLFrameFactoryWithContext:
				(nonnull id<TSVBGLDeviceContext>)context 
				API_AVAILABLE(ios(13))
				NS_SWIFT_UNAVAILABLE("Deprecated: Use newFrameFactory instead.");


/// Creates video processing pipeline. Multiple instances can be created in same time.
- (nullable id<TSVBPipeline>) newPipeline;

- (nullable id<TSVBPipeline>) newPipelineWithContext:
				(nonnull id<TSVBDeviceContext>)context 
				API_AVAILABLE(ios(13))
				NS_SWIFT_UNAVAILABLE("Deprecated: Use newPipeline instead.");

@end

#endif
