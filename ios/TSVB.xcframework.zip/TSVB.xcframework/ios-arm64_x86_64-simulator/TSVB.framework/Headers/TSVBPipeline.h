#ifndef VIDEO_EFFECTS_SDK_INCLUDE_TSVB_PIPELINE_H
#define VIDEO_EFFECTS_SDK_INCLUDE_TSVB_PIPELINE_H

#import <Foundation/Foundation.h>
#import <CoreVideo/CVPixelBuffer.h>

#import <TSVB/TSVBFrame.h>
#import <TSVB/TSVBPipelineConfiguration.h>

typedef NS_ENUM(NSInteger, TSVBPipelineError)
{
	/// Success
	TSVBPipelineErrorOk = 0,
	/// One or more arguments are incorrect.
	TSVBPipelineErrorInvalidArgument = 1,
	/// The processing pipeline is not configured.
	TSVBPipelineErrorNoFeaturesEnabled = 2,
	/// Failure to initialize, the hardware/software is not supported.
	TSVBPipelineErrorEngineInitializationError = 3,
	/// Not enough memory, disc space, VRAM, etc.
	TSVBPipelineErrorResourceAllocationError = 4
} NS_SWIFT_NAME(PipelineError);

NS_SWIFT_NAME(ReplacementController)
@protocol TSVBReplacementController<NSObject>

/// Holds custom image for background replacement.
///
/// If nil then processing replaces background by transparency. To reset the background set nil.
@property(nonatomic, retain, nullable) id<TSVBFrame> background;

@end

/// Configuration of effects and frame processor.
///
/// Use separate instances for each video stream. Can be created by ``TSVBSDKFactory``.
NS_SWIFT_NAME(Pipeline)
@protocol TSVBPipeline<NSObject>

/// Configures the pipeline, determines what to use for image processing.
-(TSVBPipelineError)setConfiguration:(id<TSVBPipelineConfiguration>_Nonnull)configuration;
/// Copies current configuration of the pipeline.
-(nullable id<TSVBPipelineConfiguration>)copyConfiguration;
/// Obtains default configuration
-(nullable id<TSVBPipelineConfiguration>)copyDefaultConfiguration;

/// Enables background blur and adjusts the intensity of the active blur effect if enabled.
///
/// - parameter power: value from 0 to 1.
-(TSVBPipelineError)enableBlurBackgroundWithPower:(float)power NS_SWIFT_NAME(enableBlurBackground(power:));
/// Disables background blur.
-(void) disableBlurBackground;

/// Enables background replacement.
///
/// The default background is transparent, the custom image for the background could be set using the property ``TSVBReplacementController/background``.
/// - parameter controller: A pointer to the variable to store an instance. Can be nil.
-(TSVBPipelineError)enableReplaceBackground:
    (id<TSVBReplacementController> __strong _Nullable* _Nullable)controller;

/// Disables background replacement.
-(void) disableReplaceBackground;

/// Enables video denoising.
///
/// By default, denoises the background only, to denoise the foreground, set ``TSVBPipeline/denoiseWithFace`` to `true`.
-(TSVBPipelineError)enableDenoiseBackground;
/// Disables denoising.
-(void) disableDenoiseBackground;
/// Higher number => more visible effect. Value from 0 to 1.
@property(nonatomic) float denoisePower;
/// If `true`, denoises both foreground (face) and background; if `false`, denoises background only. Defaults to `false`.
@property(nonatomic) bool denoiseWithFace;

/// Enables face beautification effect.
-(TSVBPipelineError)enableBeautification;
/// Disables face beautification.
-(void) disableBeautification;
/// Higher number => more visible effect of beautification. Value from 0 to 1.
@property(nonatomic) float beautificationLevel;

/// Enables ML-driven color correction
///
/// Resource preparation begins asynchronously after the first frame is processed, so the effect may apply after a short delay.
-(TSVBPipelineError)enableColorCorrection;
/// Enables color grading, automatically disabling any other active color correction effects.
///
/// Generates a color palette from reference and apply it to the video. If enabled, generates a new color palette with `referenceFrame`.
/// - parameter withReference: The reference to generate a color palette.
-(TSVBPipelineError)enableColorCorrectionWithReferance:(nonnull id<TSVBFrame>)reference;
/// Enables color filtering with a Lookup Table (Lut).
///
/// Supports only 3D Lut with maximum size 256 (256x256x256). If enabled, switches Lut.
/// - parameter withLutFile: Full path to .cube file.
-(TSVBPipelineError)enableColorCorrectionWithLutFile:(nonnull NSString*)filePath;
/// Disables color correction.
-(void) disableColorCorrection;
/// Higher number => more visible effect of beautification. Value from 0 to 1.
@property(nonatomic) float colorCorrectionPower;

/// Enables smart zoom.
///
/// Smart Zoom crops around the face.
-(TSVBPipelineError)enableSmartZoom;
/// Disables smart zoom.
-(void) disableSmartZoom;

/// Defines how much area should be filled by a face. Higher number => more area. [0, 1]
@property(nonatomic) float smartZoomLevel;

/// Enables the brightening effect.
///
/// Low Light Adjustment enhances the brightness of a dark video. It is useful when the video has a darker environment.
/// It's recommended to use together with a Color Correction effect.
-(TSVBPipelineError)enableLowLightAdjustment;
/// Disables the brightening effect.
-(void)disableLowLightAdjustment;
/// Value from 0 to 1. Higher number => brighter result. Default is 0.6.
@property(nonatomic) float lowLightAdjustmentPower;

/// Enables sharpening effect.
///
/// Sharpening makes the video look better by enhancing its clarity. It reduces blurriness in the video.
-(TSVBPipelineError)enableSharpening;
/// Disables sharpening effect.
-(void)disableSharpening;
/// Value from 0 to 1. Higher number => sharper result.
@property(nonatomic) float sharpeningPower;

/// Applies all active effects (e.g., blur, denoising, color correction) to the input frame and returns the processed result.
///
/// - parameter frame:
/// - parameter error: Output parameter for error reporting. Pass nil to ignore errors.
/// - returns: A new `frame` with effects applied, retaining the same format and dimensions as the input. If Metal (GPU) pipeline is active, the result of ``TSVBFrame/toCVPixelBuffer`` is Metal-compatible.
-(nullable id<TSVBFrame>) process:(nonnull id<TSVBFrame>)frame
							error:(nullable TSVBPipelineError*)error;

/// Same as ``TSVBPipeline/process:error:``, but expects a [CVPixelbuffer](https://developer.apple.com/documentation/corevideo/cvpixelbuffer-q2e) as an argument.
///
/// Recommended to use metal compatible [CVPixelbuffer](https://developer.apple.com/documentation/corevideo/cvpixelbuffer-q2e). The argument has not effect if CPU pipeline.
/// If you does not know pixelBuffer is metal compatible or not then set metalCompatible to false.
/// CVPixelBuffer received within [AVCaptureVideoDataOutputSampleBufferDelegate.captureOutput(_:didOutput:from:)](https://developer.apple.com/documentation/avfoundation/avcapturevideodataoutputsamplebufferdelegate/captureoutput(_:didoutput:from:)) from [AVCaptureSession](https://developer.apple.com/documentation/avfoundation/avcapturesession) is metal compatible.
///
/// For manual creating, to create metal compatible `CVPixelBuffer`, set [kCVPixelBufferMetalCompatibilityKey](https://developer.apple.com/documentation/corevideo/kcvpixelbuffermetalcompatibilitykey) attribute.
///
/// Supported `CVPixelBuffer` formats:
/// * kCVPixelFormatType_32BGRA
/// * kCVPixelFormatType_32RGBA
/// * kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange (The SDK takes into account ranges: luma=[16,235] chroma=[16,240])
/// * kCVPixelFormatType_420YpCbCr8BiPlanarFullRange
///
/// - parameter pixelBuffer: The input video frame to process.
/// - parameter metalCompatible: Set to `true` if the `CVPixelBuffer` is Metal-compatible (optimizes GPU processing). Set to `false` if unsure (forces safe mode, adding a copy overhead).
/// - parameter error: Output parameter for error reporting. Pass nil to ignore errors.
/// - returns: A new `frame` with effects applied, retaining the same format and dimensions as the input. If Metal (GPU) pipeline is active, the result of ``TSVBFrame/toCVPixelBuffer`` is Metal-compatible.
-(nullable id<TSVBFrame>)processCVPixelBuffer:(nonnull CVPixelBufferRef)pixelBuffer
							  metalCompatible:(bool)metalCompatible
										error:(nullable TSVBPipelineError*)error NS_SWIFT_NAME(process(pixelBuffer:metalCompatible:error:));

/// Same as ``TSVBPipeline/processCVPixelBuffer:metalCompatible:error:``, but has additional argument ``TSVBRotation``
-(nullable id<TSVBFrame>)processCVPixelBuffer:(nonnull CVPixelBufferRef)pixelBuffer
							  metalCompatible:(bool)metalCompatible
									 rotation:(TSVBRotation)rotation
										error:(nullable TSVBPipelineError*)error NS_SWIFT_NAME(process(pixelBuffer:metalCompatible:rotation:error:));

@end

#endif
