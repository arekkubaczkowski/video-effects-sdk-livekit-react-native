#ifndef VIDEO_EFFECTS_SDK_INCLUDE_TSVB_FRAME_H
#define VIDEO_EFFECTS_SDK_INCLUDE_TSVB_FRAME_H

#import <Foundation/Foundation.h>
#import <CoreVideo/CVPixelBuffer.h>

typedef NS_ENUM(NSInteger, TSVBFrameFormat)
{
	TSVBFrameFormatBgra32 = 1,
	TSVBFrameFormatRgba32 = 2,
	TSVBFrameFormatNv12 = 3
} NS_SWIFT_NAME(FrameFormat);

typedef NS_ENUM(NSInteger, TSVBFrameLock)
{
	TSVBFrameLockRead = 1,
	TSVBFrameLockWrite = 2,
	TSVBFrameLockReadWrite = (TSVBFrameLockRead | TSVBFrameLockWrite)
} NS_SWIFT_NAME(Lock);

typedef NS_ENUM(NSInteger, TSVBRotation)
{
	TSVBRotation_0 = 0,
	TSVBRotation_90 = 90,
	TSVBRotation_180 = 180,
	TSVBRotation_270 = 270
} NS_SWIFT_NAME(Rotation);

/// Keeps access to the data inside the frame and returns pointers to that data.
///
/// When obtained with `frame.lock(.write)` or `frame.lock(.readWrite)`, changes are applied after this instance is released.
/// If locked with `.read`, modifying data is unsafe.
NS_SWIFT_NAME(LockedFrameData)
@protocol TSVBLockedFrameData<NSObject>

/// Gets the stride (bytes per line) for a planar component.
///
/// - parameter planar: The planar index (e.g., 0 for Y, 1 for UV in NV12). see ``TSVBLockedFrameData/dataPointerOfPlanar:``
/// - returns: Stride in bytes, including padding if any.
-(unsigned int)bytesPerLineOfPlanar:(int)index;

/// Gets a pointer to the planar data.
///
/// - parameter planar: depends on frame format. For ``TSVBFrameFormat``.rgba32 or ``TSVBFrameFormat``.bgra32 always should be used 0. For NV12 0 returns pointer to Y component, 1 returns pointer to UV component.
/// - returns: Returns pointer to planar data. If the ``TSVBFrame`` was created with  ``TSVBFrameFactory/newFrameWithFormat:data:bytesPerLine:width:height:makeCopy:`` where `makeCopy` was false, this matches the original pointer.
-(nullable void*)dataPointerOfPlanar:(int)index NS_RETURNS_INNER_POINTER;

@end

NS_SWIFT_NAME(Frame)
@protocol TSVBFrame<NSObject>

/// The width of the frame in pixels.
@property(nonatomic, readonly) unsigned int width;
/// The height of the frame in pixels.
@property(nonatomic, readonly) unsigned int height;

/// Format of frame data.
@property(nonatomic, readonly) TSVBFrameFormat format;

@property(nonatomic) TSVBRotation rotation;

/// Gets access to memory of the frame.
///
/// Locks the frame, if data is not synchronized with CPU (e.g. stored on GPU)  then this method will synchronize it.
/// - note: The instance must not be accessed while the related instance of ``TSVBLockedFrameData`` exists.
/// - parameter lock: Determines access to the memory.
/// - returns: An instance which provides ability to get pointers to internal data of the frame.
-(nullable id<TSVBLockedFrameData>)lock:(TSVBFrameLock)lock;

/// Converts the frame to a  [CVPixelBuffer](https://developer.apple.com/documentation/corevideo/cvpixelbuffer-q2e) or returns its existing buffer.
///
/// - If the frame is already backed by a [CVPixelBuffer](https://developer.apple.com/documentation/corevideo/cvpixelbuffer-q2e), returns it directly.
/// - note: The instance of ``TSVBFrame`` must not be used after this method called.
/// - note: When Metal pipeline is active the result of ``TSVBPipeline/process:error:`` and ``TSVBPipeline/processCVPixelBuffer:metalCompatible:error:`` is metal compatible.
-(nullable CVPixelBufferRef)toCVPixelBuffer NS_RETURNS_INNER_POINTER;

@end

#endif
